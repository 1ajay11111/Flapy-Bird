using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipeMoveSpeed : MonoBehaviour
{
    public float Movespeed = 5;
    public float DeadZone = -100;
    // Start is called before the first frame update
    

    // Update is called once per frame
    void Update()
    {
        transform.position += Movespeed * Time.deltaTime * Vector3.left;
        if(transform.position.x < DeadZone)
        {
            Destroy(gameObject); 
        }
    }
}
