using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipeSpwanScript : MonoBehaviour
{
    public GameObject Pipe;
    public float Spwantime = 2f;
    private float timer;
    public float HeightOffset = 10f;
    // Start is called before the first frame update
    void Start()
    {
        PipeSpawn();
    }

    // Update is called once per frame
    void Update()
    {
        if(timer<Spwantime)
        {
            timer += Time.deltaTime;
        }
        else
        {
            PipeSpawn();
        }
    }
    void PipeSpawn()
    {
        float LowerPoint =transform.position.y - HeightOffset;
        float UpperPoint =transform.position.y + HeightOffset;

       Instantiate(Pipe,new Vector3(transform.position.x,Random.Range(LowerPoint,UpperPoint),0),transform.rotation);timer = 0;
    }
}
