using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LogicManager : MonoBehaviour
{
    public static LogicManager instance;
    public GameObject GameOverpanel;
    public int PlayerScore = 0;
    public Text Score;
    // Start is called before the first frame update

    private void Start()
    {
        GameOverpanel.SetActive(false);
    }
    public void AddScore(int val)
    {
        PlayerScore += val;
        Score.text = "Score : " + (PlayerScore.ToString());
    }

    private void Awake()
    { if (instance == null)
        instance = this;
    }
}
