using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver : MonoBehaviour
{
    // Start is called before the first frame update
    private void OnCollisionEnter2D(Collision2D collision)
    {
        BirdScript.instance.BirdFlying = false;
        LogicManager.instance.GameOverpanel.SetActive(true);
    }
}
